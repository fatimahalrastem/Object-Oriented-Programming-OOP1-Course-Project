public class Operations {

    public static void deleteMovie() { // delete a movie after taking the index as a user input
        for (int i = 0; i < Main.moviesArr.size(); i++) {
            System.out.println("( Index : " + i + " ) --> " + Main.moviesArr.get(i).getName());
        }
        System.out.print("Which Movie Would You Like To Select ( Index ) : ");
        int index = Main.scanner.nextInt();

        if (0 <= index && index < Main.moviesArr.size()) {
            Main.moviesArr.remove(index);
        } else {

            System.out.print("Out Of Bounds ");

        }

    }

    public static void showCostumers() { // display all costumers info after taking the movie index as a user input
        for (int i = 0; i < Main.moviesArr.size(); i++) {
            System.out.println("( Index : " + i + " ) --> " + Main.moviesArr.get(i).getName());
        }
        System.out.print("Which Movie Would You Like To Select ( Index ) : ");
        int index = Main.scanner.nextInt();

        if (0 <= index && index < Main.moviesArr.size()) {
            for (int i = 0; i < Main.moviesArr.get(index).costumersArr.size(); i++) {
                System.out.println("Name : " + Main.moviesArr.get(index).costumersArr.get(i).getName() + " | Age : "
                        + Main.moviesArr.get(index).costumersArr.get(i).getAge() + " | Seat : "
                        + Main.moviesArr.get(index).costumersArr.get(i).seat);
            }
            System.out.print("Return To Admin Menu ");

        } else {

            System.out.print("Out Of Bounds ");

        }

    }

    public static void addMovie() { // Take name , leastAge, duration, rating To Make A New Movie ,Add It To The
                                    // "arrMovies"
        String name;
        int leastAge, duration, rating;
        System.out.print("Please Enter Movie's Name : ");
        Main.scanner.nextLine(); // Taking The Crap
        name = Main.scanner.nextLine();
        System.out.print("Please Enter Movie's Least Age : ");
        leastAge = Main.scanner.nextInt();
        System.out.print("Please Enter Movie's Duration ( Minutes ) : ");
        duration = Main.scanner.nextInt();
        System.out.print("Please Enter Movie's Rating : ");
        rating = Main.scanner.nextInt();

        Movie newMovie = new Movie(name, leastAge, duration, rating);
        Main.moviesArr.add(newMovie);

    }

    public static void bookCostumer() { // Enter name , age to book costumer and seat to select it

        String name;
        int age;
        System.out.print("Please Enter ( His / Her ) Name : ");
        name = Main.scanner.next();
        System.out.print("Please Enter ( His / Her ) Age  : ");
        age = Main.scanner.nextInt();

        for (int i = 0; i < Main.moviesArr.size(); i++) {
            System.out.println("( Index : " + i + " ) --> " + Main.moviesArr.get(i).getName());
        }
        System.out.print("For Which Movie : ");
        int index = Main.scanner.nextInt();

        if (index >= 0 && index < Main.moviesArr.size()) {
            if (Main.moviesArr.get(index).getLeastAge() <= age) {

                Main.moviesArr.get(index).displayTheatre();
                System.out.print("Which Seat Would You Like To Choose : ");
                String seat = Main.scanner.next();

                if (!Main.moviesArr.get(index).isTaken(seat)) {
                    Main.moviesArr.get(index).bookSeat(seat);
                    Main.moviesArr.get(index).costumersArr.add(new Costumer(name, age, seat));
                } else {
                    System.out.println("This Seat Is Taken Please Try Another One .");
                }

            } else {
                System.out.print("Sorry You Must Be " + Main.moviesArr.get(index).getLeastAge()
                        + " Or Older To Enter This Movie. ");

            }
        } else {
            System.out.println("Wrong Input!\nPlease Try Again");
        }
    }

    public static void displayMoviesInfo() { // display all the movie info after taking the index as a user input

        for (int i = 0; i < Main.moviesArr.size(); i++) {

            System.out.println("( Index : " + i + " ) --> " + Main.moviesArr.get(i).getName());

        }
        System.out.print("Which Movie Would You Like To Display : ");
        int index = Main.scanner.nextInt();

        System.out.println("1 - Display Information . ");
        System.out.println("2 - Display Theater .");
        System.out.print("What Would You Like To Do : ");
        int choice = Main.scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.println("Movie Name : " + Main.moviesArr.get(index).getName() + " .");
                System.out.println("Least Age : " + Main.moviesArr.get(index).getLeastAge() + " .");
                System.out.println("Duration : " + Main.moviesArr.get(index).getDuration() + " Minutes .");
                System.out.print("Rating : ");
                for (int i = 0; i < Main.moviesArr.get(index).getRating(); i++) {
                    System.out.print("* ");
                }

                break;
            case 2:
                Main.moviesArr.get(index).displayTheatre();

                break;
            default:
                System.out.println("Wrong Input!\nPlease Try Again");

        }

    }

    public static void displayAllMovies() { // display all the movies info
        System.out.println("-----------------------------------------------------\n");

        for (int index = 0; index < Main.moviesArr.size(); index++) {
            System.out.println("Movie Name : " + Main.moviesArr.get(index).getName() + " .");
            System.out.println("Least Age : " + Main.moviesArr.get(index).getLeastAge() + " .");
            System.out.println("Duration : " + Main.moviesArr.get(index).getDuration() + " Minutes .");
            System.out.print("Rating : ");
            for (int i = 0; i < Main.moviesArr.get(index).getRating(); i++) {
                System.out.print("* ");
            }
            System.out.println("\n\n-----------------------------------------------------");
        }

    }

}
