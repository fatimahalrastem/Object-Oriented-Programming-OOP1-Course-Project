public class Costumer extends Person {

    String seat;

    Costumer(String name, int age, String seat) {
        super(name, age);
        this.seat = seat;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getAge() {
        return this.age;
    }

}
