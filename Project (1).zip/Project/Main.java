import java.util.*;

public class Main {
    public static Scanner scanner = new Scanner(System.in);
    public static ArrayList<Movie> moviesArr = new ArrayList<Movie>();
    public static Admin admin = new Admin("Admin", 21, "admin@email.com", "1234");

    public static void main(String[] args) {

        Sys.runApp();

    }

}
