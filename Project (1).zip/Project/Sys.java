public class Sys {

    public static void runApp() {

        System.out.println("-----   X Movies   ----   ");
        System.out.println("1 - Display All Movies .");
        System.out.println("2 - Book A Costumer .");
        System.out.println("3 - Information About A Movie . ");
        System.out.println("0 - Exit . ");
        System.out.print("What Would You Like To Do : ");
        int choice = Main.scanner.nextInt();

        switch (choice) {
            case 1:
                // Operations.addMovie();
                Operations.displayAllMovies();
                break;
            case 2:
                Operations.bookCostumer();
                break;
            case 3:
                Operations.displayMoviesInfo();
                break;
            case 9:
                String email, password;

                System.out.print("Please Enter Admin Email : ");
                email = Main.scanner.next();
                System.out.print("Please Enter Admin PCode : ");
                password = Main.scanner.next();
                if (Main.admin.getEmail().equalsIgnoreCase(email) && Main.admin.getPassowrd().equals(password)) {
                    Admin.runAdmin();
                } else {
                    System.out.println("Wong Password Or Email !\nPlease Try Again.");

                }

        }

        if (choice != 0) {
            runApp();
        }

    }

}
